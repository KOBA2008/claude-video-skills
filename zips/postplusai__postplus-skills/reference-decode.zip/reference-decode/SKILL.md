---
name: reference-decode
description: Turn reference videos, frames, or contact sheets into reusable hook and visual rules for new creative prompts, with clear imitation boundaries.
metadata:
  postplus:
    familyId: routing-contracts
    familyName: Routing & Contracts
---

# Reference Decode

## Use When
- A benchmark video, contact sheet, frame set, rough idea, or source material
  needs to become promptable structure.
- You need the hook essence, viewer question, visual grammar, and forbidden
  drift before storyboard or request writing.
- A no-reference brief still needs a proxy structure before prompt work.

## Do Not Use When
- Do not create the final storyboard grid or execution request here.
- Do not copy faces, exact wardrobe, creator identity, exact location, or exact
  overlays from benchmark material.

## Core Rule
Do not summarize references as "good vibe", "nice pacing", or "strong
chemistry". Extract four objects:

- `hookEssence`
- `viewerQuestion`
- `mustCopyVisualGrammar`
- `forbiddenDrift`

## Default Workflow
1. Use the smallest sufficient source set: hook-first clip, first 0-5 seconds,
   hook-first contact sheet, supporting note, or full style board only if needed.
2. Decode the opening mechanism: first clear promise, viewer question, and the
   exact visual structure that makes the promise legible.
3. Separate structure from identity. Keep camera grammar, shot order, object
   logic, timing, and relationship logic; do not keep exact identity details.
4. Create a compact decode artifact when it is useful.
5. Carry the decode block into storyboard or request writing as internal context. Show it only when requested or needed to explain a creative choice.

## No-Reference Mode
When no usable reference exists, operate in proxy mode:

- start from the chosen segment pattern
- infer the likely viewer question
- express must-copy grammar as scene anchors, not imitation notes
- express forbidden drift as anti-generic safeguards
- state that the output is brief-derived, not observed from footage

## Output Shape
The artifact contains `hookEssence`, `viewerQuestion`, `mustCopyVisualGrammar`, and
`forbiddenDrift`.

## Stop Conditions
- Stop when required user intent, source evidence, or owned input artifacts are
  missing and guessing would change the result.


## Handoff
- For a grid or panel plan, preserve the decoded evidence in the requested layout before image generation.
- Image generation -> `image-batch-runner`.
- Video generation -> `video-batch-runner`; pass the useful decoded grammar as
  context, not as a second contract file.

## Public Command Boundary

- Choose the smallest matching command or workflow from the user input and run
  it directly.

- This public skill is instruction-driven. Produce the artifact described by the workflow directly from the available evidence.
- Do not use unpublished execution paths or local tools.
- Requested tasks use existing PostPlus credits after the current price and balance are checked.
  Estimate-only requests do not execute. Stop on insufficient credits; do not
  recharge, buy a subscription, or repeat an uncertain paid operation.
