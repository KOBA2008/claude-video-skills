# Instagram Shared Contract

## Complete the research

Use the user's decision as the completion criterion. For broad content or
competitor discovery, aim for roughly **100–150 relevant distinct reviewable
items**; for creator discovery, roughly **20–30 evidence-backed creators**.
These are adjustable research goals, not request limits or guaranteed inventory.
A narrow account audit, exact URLs, explicit small sample, time limit, or budget
wins. Do not broaden an exact-object request to fill a quota.

Start with grounded product, problem, use-case, competitor, and hashtag
queries. Inspect completed results; expand promising authors, brands, phrases,
and tags rather than fixing a tiny seed list. Continue successful sparse/noisy
searches while grounded changed searches add useful evidence. Do not hand the
research back to the user after a small first pass or two follow-ups.

Stop when the requested outcome is met, an explicit limit is reached, grounded
new directions cease adding useful distinct material, or a hard execution error
blocks progress. Report actual coverage and the gap, not invented completeness.
Do not repeat identical requests as pagination or bypass a failed/pending run.
Preserve completed evidence when a later batch fails. Follow the returned recovery
action for that operation; a terminal failure does not prohibit a separate,
evidence-grounded research direction. Do not claim that all directions are
exhausted because one batch failed.
Reuse existing explicit spending authorization that covers the work; do not ask
for approval again for already-authorized batches.

## Platform details and quantities

- `instagram-hashtags --query "oily skin sunscreen" --kind reels` finds topic
  content; `--hashtag sunscreen` finds hashtag content. Do not mix both modes.
- `instagram-posts --handle example` collects account posts;
  `instagram-posts --url "https://www.instagram.com/p/EXAMPLE/"` collects a known
  post. Use one mode per request; a post URL is not a handle.
- Search results are candidates; verify selected profiles/posts before relying
  on account identity. Tagged-tab, Stories, Shop, LIVE, private metrics, follower
  lists, and full mention graphs are outside this surface.
- Hashtag/query and account limits apply per seed. Direct post URLs each select
  one post; `--limit` does not expand that direct-URL selection.

A request limit is not a global research cap. Plan multi-seed requests using the
route's per-seed semantics; report requested scopes, raw rows, distinct items,
relevant items, and actual CLI-reported costs separately. Never estimate actual
spend from row count alone. Preserve results above a requested count.

## Evidence and progress

Keep original JSON, source URLs, observation dates, batch statuses, and reported
costs. Deduplicate by platform identity/canonical URL, retaining all search
sources. Missing metrics are unknown, not zero. Separate direct/relevant,
adjacent, irrelevant, and uncertain material; only relevant usable items count
toward the primary target. Keep useful non-video formats in their own category.

Initial filtering can use captions, returned fields, and profiles. Claims about
visual openings, shots, sound, and proof moments require `media-analysis` on
selected media; captions alone cannot establish them. Audience pain points need
actual comments, not captions or engagement counts. An unavailable video or
missing comment set is a recorded gap. Public samples do not establish sales,
causality, audience demographics, or platform-wide rankings.

During longer work, report completed scope, relevant distinct counts,
duplicates/missing media, and the next evidence gap. Save and update artifacts
incrementally. A short chat summary must not truncate the underlying evidence.

## Fixed report and user corrections

Generate the standard report from every supported content/profile/comment result
file, including failed, empty, and pending envelopes; never hand-build a random
HTML gallery. Public contact results from `instagram-email-search` remain separate raw
evidence; do not pass that unsupported route to the report.

```bash
postplus research report --input batch-01.json --input batch-02.json --output research.html
postplus research report --analysis-schema
```

The first report exposes stable evidence IDs; the schema defines analysis input.
Use those IDs and the returned schema to write `findings.json`, then regenerate:

```bash
postplus research report --input batch-01.json --input batch-02.json --analysis findings.json --output research.html
```

Raw evidence must remain browsable without analysis. Normal research delivery
adds relevance, recommendation reasons, criterion judgments, and source
references using the supported schema. Never invent fields or reference IDs.
Keep all useful evidence, with a concise recommended selection. Rebuild as new
batches arrive. For a user's chat correction, reuse IDs and prior evidence,
revise the relevant criteria/selection, and collect only the missing evidence.
Do not imply the static page automatically saves user feedback.

For comment browsing, include both the source post batches and their comment
batches with repeated `--input`. If the source post is missing, use
`postplus research run instagram-posts --url "<original-post-url>" --wait --output source-post.json` through the
normal quoted collection flow. The report displays saved comments and replies;
opening a detail does not fetch more. An uncollected comment set is not zero
comments. Keep creator profile and representative-work batches together when
delivering a creator shortlist.

## Deliver and continue appropriately

Deliver scope, actual counts, key findings, unknowns, reported cost, and artifact
paths. Include criterion evidence for recommendations. Complete requested
analysis/brief/script work using the relevant downstream skill; do not stop at
search when the original request includes that work.

Reuse saved evidence and completed analyses. Read only the downstream skill
needed for the current decision:

- `media-analysis`: selected original URLs for the fixed full analysis report; answer the user question from that saved report.
- `reddit-search`: product/problem hypotheses and existing evidence when long-form
  discussion is requested or needed by the original research scope.
- `benchmark-to-brief`: product facts, patterns, source references, and uncertainties.
- `reference-decode`: selected references and existing media analysis for reusable
  structure; then the requested creative skill when scripts are in scope.
- Creator/account audit: shortlisted handles, content evidence, explicit criteria,
  and unresolved conditions. Contacting creators requires explicit authorization.

At the end, offer one concrete next action in the user's language when useful.
Keep the corresponding skill and routing choice internal. Do not automatically
begin a new goal.

For media follow-up, obtain or reuse the fixed full media-analysis report, then answer the user question from that evidence. Do not pass a custom analysis prompt or purchase another analysis merely to change the question. Keep skill names and routing choices internal unless the user asks about the workflow.
